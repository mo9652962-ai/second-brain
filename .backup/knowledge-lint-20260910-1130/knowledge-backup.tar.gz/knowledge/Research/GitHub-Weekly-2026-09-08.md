---
tags: [github, github-trending, weekly, research]
type: note
created: 2026-09-08
---

# GitHub 宝藏挖掘 - 2026-09-08

## Top 5

### 1. DeusData/codebase-memory-mcp (42,605⭐) [🔴]
- Score: 87/100 | Lang: C | License: MIT
- High-performance code intelligence MCP server. Indexes codebases into a persistent knowledge graph — average repo in milliseconds. 158 languages, sub-ms queries, 99% fewer tokens. Single static binary
- URL: https://github.com/DeusData/codebase-memory-mcp

### 2. HKUDS/nanobot (47,865⭐) [🔴]
- Score: 81/100 | Lang: Python | License: MIT
- Ultra-lightweight, open-source, self-hosted personal AI agent framework in Python with WebUI, tools, memory, MCP, multi-agent workflows, automation, and chat apps
- URL: https://github.com/HKUDS/nanobot

### 3. tirth8205/code-review-graph (31,243⭐) [🔴]
- Score: 73/100 | Lang: Python | License: MIT
- Local-first code intelligence graph for MCP and CLI. Builds a persistent map of your codebase so AI coding tools read only what matters, with benchmarked context reductions on reviews and large-repo w
- URL: https://github.com/tirth8205/code-review-graph

### 4. ChromeDevTools/chrome-devtools-mcp (51,307⭐) [🟡]
- Score: 69/100 | Lang: TypeScript | License: Apache-2.0
- Chrome DevTools for coding agents
- URL: https://github.com/ChromeDevTools/chrome-devtools-mcp

### 5. langgenius/dify (154,906⭐) [🟡]
- Score: 62/100 | Lang: TypeScript | License: NOASSERTION
- Build Agentic workflows, RAG pipelines, with rich AI model and tool support on one collaborative workspace. Deploy on cloud, VPC, or self-hosted, so teams move from prototype to production without reb
- URL: https://github.com/langgenius/dify

## MCP 生态发现

- **DeusData/codebase-memory-mcp** (87/100): High-performance code intelligence MCP server. Indexes codebases into a persistent knowledge graph — average repo in milliseconds. 158 languages, sub-
- **HKUDS/nanobot** (81/100): Ultra-lightweight, open-source, self-hosted personal AI agent framework in Python with WebUI, tools, memory, MCP, multi-agent workflows, automation, a
- **tirth8205/code-review-graph** (73/100): Local-first code intelligence graph for MCP and CLI. Builds a persistent map of your codebase so AI coding tools read only what matters, with benchmar

## 洞察

1. MCP 持续成为 Agent 标准接口
2. 本地优先是主流趋势
3. 记忆系统是核心突破点

---
*自动生成 2026-09-08 12:43*

---
> 🗺️ 属于 [[MOC-Research]] · [[Home|🏠 Home]]
