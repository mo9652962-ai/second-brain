---
title: "AI 博主 · 10 轮研究全览"
type: note
domain: Productivity
status: active
tags: [knowledge/productivity]
source: null
---
# AI 博主 · 10 轮研究全览

> 2026-07-27 · 覆盖 6 个领域 + 定位 + 变现 + 竞品 + 路线图

---

## Round 1: AI + Office/WPS 自动化

**现状**：WPS AI / Notion AI / Gamma 已经成熟
- WPS AI：嵌入 WPS，一键生成文档/PPT/表格
- Gamma：AI PPT 生成，设计师友好
- 论文写作：Light Skills + 攻玉 + 各种 AI 论文工具

**内容机会**：
- ✅ 论文写作"去AI化"实战
- ✅ AI + Office 自动化工作流
- ✅ 降AI率工具测评（笔灵/零感/森克兰特）

**已有基础**：Light Skills（paper-writing/citation/consistency）+ Gamma

## Round 2: AI + 自动化编程

**现状**：Claude Code / Codex / OpenCode 三足鼎立
- Claude Code：最强的跨文件理解，但贵
- Codex：最成熟的多 Agent 编排，有额度问题
- OpenCode：开源，模型无关，成本低

**内容机会**：
- ✅ Claude Code vs Codex vs OpenCode 横向测评
- ✅ 零基础用 AI 编程做项目
- ✅ Agent Skills 最佳实践
- ✅ Cursor + AI 编程工作流

**已有基础**：opencode-go + Hermes + 22 cron + Light Skills

## Round 3: AI + 修图

**现状**：2026 年格局大洗牌
- **GPT Image 2**：Elo 评分碾压（1512 vs MJ V7 的 1270），文字渲染 99%
- **Midjourney V7**：艺术质感仍是王者
- **FLUX**：本地部署优势，隐私安全
- **Recraft**：向量输出唯一选择
- **即梦 Jimeng**：中文最友好

**内容机会**：
- ✅ 电商主图 AI 生成全流程
- ✅ AI 修图 vs 传统 PS 对比
- ✅ 各工具横向测评（GPT Image vs MJ vs FLUX）
- ✅ 透明背景图生成（alpha channel）→ 闲鱼配图

**已有基础**：xAI Grok Imagine

## Round 4: AI + 工程自动化（CAD/PCB/单片机/机械）

**现状**：转型初期，潜力巨大
- **Autodesk**：Fusion AI 原生增强
- **嘉立创 EDA**：MCP 接口，38 个 PCB 工具
- **西门子**：EDA/PCB 生成式 Agent
- **提示词工程师**成为 EDA 新职业
- **AIAD（AI辅助设计）** 成为 CAD/CG 2026 核心议题

**内容机会**：
- ✅ AI + PCB 设计实战（你有 jlcmcp！）
- ✅ CAD 软件 AI 化趋势解读
- ✅ AI 辅助单片机编程（ESP32/STM32）
- ✅ 提示词工程师——工程领域新岗位

**已有基础**：嘉立创 EDA + jlcmcp MCP（38 工具）

## Round 5: AI + 视频剪辑

**现状**：多强争霸
- **Veo 3.1**：最佳电影级生成（Google）
- **Runway Gen-4**：最强编辑+控制套件
- **Seedance 2.0**（字节跳动）：叙事型最佳，中文友好
- **Kling 3.0**（快手）：创作者最友好，免费额度大方
- **CapCut**：整合 AI 功能最多

**内容机会**：
- ✅ AI 视频工具横向测评
- ✅ 从文字到视频全流程
- ✅ 电商产品视频 AI 制作
- ✅ AI 视频 vs 传统剪辑对比

## Round 6: AI + 硬件机器人

**现状**：CES 2026 核心趋势——"物理 AI"
- NVIDIA + 宇树 + 星动纪元 等 87+ 家展商
- 人形机器人价格降至万元级（Mini π / Mini Hi）
- 开源硬件 + AI 门槛降低
- ESP32 + AI 边缘计算

**内容机会**：
- ✅ AI 机器人开发入门
- ✅ 低成本 AI 硬件项目（ESP32 + LLM）
- ✅ 人形机器人行业分析
- ✅ AI + 单片机实战

**已有基础**：随身WiFi 赫电 Pro + 8051 嵌入式开发 skill

## Round 7: 博主定位策略

**你最大的差异化**：**实战派** + **多领域覆盖** + **已有闲鱼变现**

**建议定位**：
```
AI 自动化实战家 — 不聊理论，只做能跑的
▸ 论文/Office ⏐ 编程 ⏐ 修图 ⏐ 工程 ⏐ 视频 ⏐ 硬件
```

**平台选择**（参考成功案例）：
| 平台 | 定位 | 内容形式 |
|:-----|:------|:---------|
| **B站** | 主阵地 | 深度教程 + 实战演示（10-20min） |
| **小红书** | 引流测试 | 工具测评卡片 + 简短教程 |
| **知乎** | 长尾 SEO | 工具对比文 + 万字教程 |
| **X/Twitter** | 行业人设 | 短推 + 工作流截图 |

## Round 8: 变现路径

**2026 年趋势**：从"卖课"转向"卖 AI 交付系统"

| 阶段 | 变现方式 | 预期收入 |
|:-----|:---------|:---------|
| 初期 | 闲鱼接单（已有） | 30-800元/单 |
| 初期 | 平台激励（B站/即梦等） | 流量补贴 |
| 中期 | 付费社群/知识库 | 199元/月 |
| 中期 | 工具测评 + 联盟营销 | 按转化 |
| 后期 | AI 工具/SaaS 订阅 | 持续收入 |

**你已经有闲鱼基础**，其余是延伸。

## Round 9: 竞品分析

| 类型 | 代表博主 | 特点 | 你的差异化 |
|:-----|:---------|:-----|:----------|
| 编程类 | 熠辉（X） | AI编程教程+项目 | 你覆盖更多领域 |
| 测评类 | 秋芝2046 | AI工具横向测评 | 你更有实战深度 |
| 硬核类 | 李沐 | 论文讲解+代码 | 你更贴近落地 |
| 工程类 | 较少 | — | **蓝海**，竞争极小 |

**最大机会点**：工程自动化领域（CAD/PCB/单片机）几乎没有成熟博主

## Round 10: 工具选型 + 路线图

### 建议工具链

| 领域 | 主工具 | 后备 |
|:-----|:-------|:-----|
| Office | WPS AI + Gamma | Notion AI |
| 编程 | Hermes + opencode-go | Codex |
| 修图 | Grok Imagine + FLUX | Midjourney V7 |
| PCB | 嘉立创 EDA + jlcmcp | KiCad |
| 视频 | CapCut + Kling/Runway | Seedance |
| 硬件 | ESP32 + Arduino | 树莓派 |

### 起步路线图

```
第1-2周：选平台（建议B站）+ 发第1个视频 → AI工具横向测评
第3-4周：发专业领域内容 → 你最熟悉的（PCB/论文）
第5-6周：建立系列 → "AI自动化实战"系列
第7-8周：社群冷启动 → X/Twitter 同步
第9周起：持续输出 + 变现尝试
```

B站上工程自动化（CAD/PCB/单片机）内容几乎没有——**这是你的蓝海赛道**。

---
> 🗺️ 属于 [[MOC-Productivity]] · [[Home|🏠 Home]]
