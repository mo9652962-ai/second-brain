---
title: "Vibe Coding 技术拆解：用 AI 搭建小程序前端框架（2026-08-30）"
type: note
domain: Productivity
status: active
tags: [knowledge/productivity]
source: null
date: 2026-08-30
---
# Vibe Coding 技术拆解：用 AI 搭建小程序前端框架（2026-08-30）

> 来源：抖音「敲代码的小虾米」《Vibe Coding技术拆解：用AI搭建一套小程序的前端架》（9min，6032赞）
> 配套上一篇：vibe-coding-要不要学代码-2026-08-30.md
> 关键词：vibecoding, 小程序, 前端框架, SDD, 多Agent

## 一句话拆解
AI 搭小程序前端 = **先写规格（Spec）当合同，再让 AI 按合同履约**，而不是"抽卡式"反复生成。核心从"写代码"变成"写规范和当架构师"。

## 一、核心范式演进（三个阶段）

| 阶段 | 模式 | 特点 | 适合 |
|:---|:---|:---|:---|
| 1 | Prompt 抽卡 | 不断生成直到满意 | ❌ 大型项目灾难，逻辑随每次生成漂移 |
| 2 | Prompt 工程 | 角色+规范+上下文约束 | ✅ 小项目可用 |
| 3 | **SDD + 多 Agent** | 先写 Spec 再写码，虚拟团队分工 | ✅✅ 生产级标准 |

**抽卡为什么是灾难**：没有 Spec 时，AI 根据概率预测代码，每次生成都在变，无法维护。

## 二、SDD（Spec-Driven Development）核心方法论

**概念**：Spec 是合同，代码是履约结果。
- 先写"说明书"（PRD/接口定义/UI行为/测试用例），再让 AI 写代码
- 有 Spec → AI 不跑偏；Spec 就是验收标准（返回 code:200 = 违约 = Bug）

**标准流程**：
1. **PM Agent**：多轮对话确定需求，生成 PRD（Markdown）
2. **Designer Agent**：根据 PRD 生成 UI 设计描述
3. **Coder Agent**：根据 PRD+设计稿生成代码
4. **Test Agent**：验证代码是否符合 PRD

## 三、小程序前端搭建实战要点（本视频核心）

### 技术栈选择：原生 vs 框架
- **AI 初级阶段建议原生小程序**（WXML/WXSS/JS）
  - 大模型对原生微信语法掌握比 UniApp 更精准（框架生命周期/语法糖容易混淆）
  - AI 训练数据中海量原生代码，Bug 率最低
  - 轻量工具用原生，不引入框架增加打包体积
- **多端需求才考虑 UniApp/Vue3**（结构统一，跨 H5/App 改动少）

### 四步搭建法（左诗右码实战验证）
1. **定基调**：技术栈+架构约束（Role/Project Goal/Tech Stack/File Structure）
   - 强制 ES6、camelCase、禁止 TS（如需）
2. **定颜值**：设计 Token（uni.scss 全局变量）
   - 主色/辅助色/中性色/圆角/间距——喂调色板，禁止 AI 自由发挥颜色
3. **造轮子**：先封装基础组件（BaseButton/BaseCard/BaseModal）
   - **不要直接写页面**！先让 AI 把通用组件封装好
4. **写业务**：页面开发带"参考系"（用已封装组件+全局变量）

### 小程序特性注意
- 逻辑层(JS/JsCore) 与视图层(WXML/WebView) 分离，数据通信需 Native 序列化
- **避免频繁 setData 大对象**（性能关键）
- 页面结构 → 数据请求 → 交互逻辑 → 样式，**拆模块生成**，不一次全要

## 四、AI 生成代码后的三道工序
1. **Refine（精炼）**：不要推翻重来，针对生成代码微调，告诉 AI 哪里错了
2. **Context（上下文）**：明确约束（"不要用 TypeScript"），给足项目背景
3. **Review（审核）**：必须人工审核，尤其数据安全/性能部分

## 五、对 sora 的可执行落点

| 关联点 | 建议 |
|:---|:---|
| **墨题**（Vue3 刷题机） | 已有前端基础 → 接小程序单可直接用 SDD 流程 |
| **闲鱼接单**（小程序需求） | 用这套 SOP：先让 AI 生成 PRD 合同 → Cursor/Trae 履约 → 人工 review |
| **Skill 沉淀** | 可参照 CSDN 案例把"原型图+接口文档+资源"交给 AI 的流程写成 skill |
| **现有工具链** | 墨题已用 HBuilderX/uni-app → AI 生成时注意框架语法混淆坑 |

**接单建议**：小程序接单用 SDD 流程可以显著降低"改需求反复返工"风险——先定 Spec 合同，客户确认后再开发。

## 六、企业级案例参考（优码云三端交付）
- 用 Cursor 生成微信+支付宝+抖音三端原生代码（2小时），人工 review 40小时
- AI 承担约 70% 代码量，但 **支付/登录/手机号授权必须人工重写**
- 私有组件库 + .cursorrules → UI review 返工率 35%→12%
- 审核坑：抖音积分商城需《增值电信业务经营许可证》，上线前先平台类目预审

## 反模式清单
- ❌ Prompt 抽卡式开发（无 Spec，逻辑漂移）
- ❌ 一次让 AI 生成整个页面/整个项目
- ❌ 让 AI 自由发挥颜色/设计
- ❌ 跳过 Code Review（尤其支付/登录/数据安全）
- ❌ 忘记 setData 性能（小程序逻辑层/视图层分离特性）

## 工具链
- **Trae**（trae.cn）：AI 集成 IDE，小程序开发首选，能直接改真实文件
- **Cursor**：Composer 模式多文件生成，wxml/wxss 语法理解准
- **HBuilderX**：uni-app 官方编辑器，一键生成项目骨架
- **微信开发者工具**：预览/真机调试/上传审核
- **Gemini**：适合当"首席产品经理"生成 PRD（规划能力强）

## 参考
- 掘金 7595831738233257993：从Prompt到产品（SDD 详细流程）
- 掘金 7605547012050960425：完整小程序实战（80% AI 代码）
- datawhale easy-vibe：微信小程序教程（Trae+HBuilderX+开发者工具）
- CSDN uniapp-vue3-skills：把流程沉淀为 Skill（docs 承载事实）
- 左诗右码：四步搭建法 Prompt 清单（定基调/定颜值/造轮子/写业务）
- 优码云：企业级三端交付拆解

---
> 🗺️ 属于 [[MOC-Productivity]] · [[Home|🏠 Home]]
