---
tags: [pcb, hardware, EDA, design-notes]
domain: Hardware
status: adopted
---
# PCB 设计学习笔记

来源：10 轮搜索引擎研究 + 整合成 skill
更新：2026-07-25

## Skill 已创建

➡️ `skills/hardware/pcb-design/SKILL.md`

## 研究覆盖范围

| 轮次 | 研究主题 | 关键发现 |
|:----:|:---------|:---------|
| ① | EDA 工具对比 | KiCad 免费无限制、立创EDA 新手友好 |
| ② | 工具选型 | 个人用 KiCad 或 立创EDA |
| ③ | 制板工艺 | 嘉立创 4mil 线宽/线隙，0.2mm 钻孔 |
| ④ | 原理图设计规范 | ERC 检查、封装管理 |
| ⑤ | PCB 布局布线 | 叠层设计、线宽参考、差分对 |
| ⑥ | 生产文件 | Gerber RS-274X 输出规范 |
| ⑦ | DFM 制造设计 | 嘉立创工艺参数、免费打样 |
| ⑧ | EMC/SI 设计 | 地平面、去耦、模拟数字分区 |
| ⑨ | SMT 贴片工艺 | 钢网、回流焊、BOM |
| ⑩ | 闲鱼接单 | 定价 50-800 元、交付物清单 |

---

## 🔗 知识关联

- **[[jlc-mcp-setup]]** — 嘉立创 MCP 桥接配置与使用
- **[[pcb-ai-research]]** — AI 辅助 PCB 设计研究
- **[[8051-MCU]]** — 嵌入式 MCU 开发
- **[[CAD-Design]]** — 3D 建模与 CAD 设计

---
> 关联: [[8051-MCU]] · [[CAD-Design]] · [[jlc-mcp-setup]] · [[Cross-Domain|🔀 知识地图]] | [[HOME|🏠 首页]]
