---
title: "MineValiCoder: Reliable Code Generation with Test Case Quality Mining"
type: note
domain: Research
status: active
tags: [knowledge/research]
source: null
---
# MineValiCoder: Reliable Code Generation with Test Case Quality Mining

| 元数据 |  |
|:-------|:--|
| **ID** | [`2607.22471`](https://arxiv.org/abs/2607.22471) |
| **日期** | 2026-07-24 |
| **分类** | cs.SE, cs.AI |
| **作者** | Zhen Zhao, Qihang Yang, Feifei Dai, Xiangfang Li, Bo Li |

---

## 核心贡献

现有 LLM 驱动的 TDD 代码生成依赖**人工编写测试用例**，无法仅从自然语言需求工作。自动生成测试用例时，LLM 的随机性导致两个致命缺陷：

1. **有缺陷的测试** → 产生误导性反馈，扭曲代码优化方向
2. **质量参差不齐的测试** → 冲突的评价信号，阻碍可靠代码选择

**MineValiCoder 的突破：** 基于**测试用例质量与代码质量双向增强**的闭环 TDD 框架。

## 三大模块

```
自然语言需求
     │
     ▼
┌─────────────────────┐
│  TCQM 模块           │  ← 测试用例质量挖掘
│  通过自我验证过滤缺陷  │     自验证 → 筛掉坏测试
│  测试，提供可靠监督    │
└────────┬────────────┘
         │ 高质量测试用例
         ▼
┌─────────────────────┐
│  并行 TDD 精炼模块    │  ← 迭代优化代码
│  使用已验证测试反馈    │     并行生成多样候选
│  迭代优化 + 多样化    │
└────────┬────────────┘
         │ 候选代码 + 测试
         ▼
┌─────────────────────┐
│  BiCoTeV 模块        │  ← 二部图互验
│  代码-测试二部图建模   │     稳定选出最优代码
│  互验评分 → 最优选择  │
└─────────────────────┘
         │
         ▼
     最优代码
```

## 关键结果

| 基准 | Pass@1 | 对比 SOTA |
|:-----|:------:|:----------|
| **HumanEval** | **96.34%** | 🥇 显著超越 |
| **MBPP** | **87.40%** | 🥇 显著超越 |
| **APPS** | **64.00%** | 🥇 显著超越 |
| **LiveCodeBench** | **51.33%** | 🥇 显著超越 |

横跨 4 个 LLM 的评估，全面超越现有方法。

## 与 sora 的关联 🔗

sora 的 engineering-workflow 中 TDD 是核心环节（红绿重构），这篇论文直接给出了**让 TDD 更可靠的工程方案**：

1. **TCQM 思路 →** 在 test-first 之前先验证测试本身的质量，避免"坏测试驱动坏代码"
2. **BiCoTeV 互验 →** 代码-测试双向验证，比单一覆盖率指标更可靠
3. **并行候选 →** 多候选择优，比单条路径迭代更鲁棒

**可借鉴到 `engineering-workflow` skill：**
- 增加"测试质量审计"步骤（先验证测试，再验证代码）
- 代码生成时考虑多候选 + 互验评分策略
- 闲鱼接代码单时可用此框架提升交付质量

---

*吸收状态: adopted — 与 TDD 工程流程直接相关，已标记注入 engineering-workflow skill*

---
> 🗺️ 属于 [[MOC-Research]] · [[Home|🏠 Home]]
