---
title: "Memvid + n8n MCP + kaeru 十轮深度研究"
type: note
domain: Research
status: active
tags: [knowledge/research]
source: null
---
# Memvid + n8n MCP + kaeru 十轮深度研究

## 📊 研究概况

| 项目 | Stars | 语言 | License | 核心价值 |
|------|-------|------|---------|---------|
| Memvid | 16k+ | Rust 98% | Apache 2.0 | 单文件 AI 内存层 |
| n8n | 198k+ | TypeScript | Fair-code | 工作流自动化 + MCP |
| kaeru | 新兴 | Rust | TBD | 本地认知记忆 MCP |

---

## 🔬 十轮维度评估

| 维度 | Memvid | n8n MCP | kaeru |
|------|--------|---------|-------|
| 1. 基本信息 | 16k stars, Rust, Apache 2.0 | 198k stars, TS, Fair-code | 新兴, Rust |
| 2. 活跃度 | 261 commits, v2.0.140 | 22,283 commits, weekly releases | 早期但活跃 |
| 3. 技术架构 | .mv2 单文件, WAL+HNSW+BM25 | Node.js monorepo, turbo | CozoDB+RocksDB, 单二进制 |
| 4. MCP 支持 | ✅ 原生支持 | ✅ 官方 MCP Server | ✅ MCP 服务器 |
| 5. SB 契合度 | ⭐⭐⭐⭐⭐ 极度契合 | ⭐⭐⭐⭐ 高契合 | ⭐⭐⭐⭐⭐ 极度契合 |
| 6. 同类对比 | 超越向量数据库 1372x | 超越 Zapier (开源+自托管) | 超越 Anthropic Memory |
| 7. 风险评估 | 低 (Apache 2.0, 活跃社区) | 中 (Fair-code 许可限制) | 低-中 (早期项目) |
| 8. 集成成本 | 低 (pip install, 零配置) | 中 (需 Docker/Node) | 低 (单二进制) |
| 9. ROI 预测 | 极高 (即插即用) | 高 (生态对接) | 高 (高级记忆) |
| 10. 行动建议 | 🔴 立即集成 | 🟡 下一阶段 | 🟡 跟踪观察 |

---

## 🎯 Memvid 深度分析

### 架构亮点

```
┌────────────────────────────────────────────────┐
│             .mv2 单文件内存层                    │
├────────────────────────────────────────────────┤
│ ┌──────────┐ ┌──────────┐ ┌──────────┐         │
│ │ Header   │ │ WAL      │ │ Data     │         │
│ │ (4KB)    │ │ (1-64MB) │ │ Segments │         │
│ └──────────┘ └──────────┘ └──────────┘         │
│ ┌──────────┐ ┌──────────┐ ┌──────────┐         │
│ │ Lex      │ │ Vec      │ │ Time     │         │
│ │ (BM25)   │ │ (HNSW)   │ │ Index    │         │
│ └──────────┘ └──────────┘ └──────────┘         │
│ ┌─────────────────────────────────────────┐    │
│ │ TOC (Segment Offsets)                   │    │
│ └─────────────────────────────────────────┘    │
└────────────────────────────────────────────────┘
```

### 性能基准

| 指标 | Memvid | 行业平均 | 提升倍数 |
|------|--------|---------|---------|
| LoCoMo 总分 | +35% SOTA | 基线 | -- |
| Multi-hop 推理 | +76% | 平均 | 1.76x |
| Temporal 推理 | +56% | 平均 | 1.56x |
| P50 延迟 | 0.025ms | 30ms+ | 1200x |
| 吞吐量 | 1372x | 基线 | 1372x |

### 与 Hermes 的集成路径

```yaml
# 1. 安装 Python SDK
pip install memvid-sdk

# 2. 创建记忆文件
python -c "
from memvid import Memvid
mv = Memvid.create('hermes-memory.mv2')
mv.put('用户偏好：喜欢中文回复，高效但温柔')
mv.commit()
"

# 3. 在 Hermes 中配置
# 通过 MCP 或直接 API 调用
```

### 评分：**95/100** 🔴 立即集成

---

## 🔗 n8n MCP 深度分析

### 核心能力

| 能力 | 说明 | 工具示例 |
|------|------|---------|
| 工作流创建 | 自然语言→完整工作流 | `workflow_create` |
| 工作流触发 | 手动/定时启动 | `workflow_execute` |
| 节点管理 | 添加/修改节点 | `node_create` |
| 集成调用 | 调用 1500+ 集成 | 通过工作流间接 |

### MCP 服务器配置

```json
{
  "mcpServers": {
    "n8n": {
      "command": "npx",
      "args": ["@n8n/mcp-server"],
      "env": {
        "N8N_API_URL": "http://localhost:5678/api/v1",
        "N8N_API_KEY": "your-api-key"
      }
    }
  }
}
```

### 与 Second Brain 的集成场景

1. **自动博客发布**: 知识库更新 → n8n → 发布到 B站/知乎/X
2. **微信通知**: GitHub Trending 结果 → n8n → 微信推送
3. **数据同步**: Obsidian → n8n → Google Calendar / Notion

### 评分：**88/100** 🟡 下一阶段集成

---

## 🧠 kaeru 深度分析

### 独特价值

- **双时态知识图谱**: 记录事实 + 记录事实的时间
- **增量更新**: 不像 GraphRAG 需要批处理
- **MCP 原生**: 单 Rust 二进制，零外部依赖
- **多 Agent 共用**: 多个 Agent 共享同一记忆

### 与 Memvid 的差异

| 维度 | Memvid | kaeru |
|------|--------|-------|
| 存储 | 单文件 .mv2 | CozoDB / RocksDB |
| 索引 | HNSW + BM25 | 知识图谱遍历 |
| 适用场景 | 通用记忆 | 复杂关系推理 |
| 部署复杂度 | 零 | 低 (单二进制) |
| 多 Agent | 支持 | 原生多 Agent |

### 评分：**待持续追踪** 🟡

---

## 📋 集成行动计划

### 本周 (7/29 - 8/1)

1. ✅ pip install memvid-sdk
2. ✅ 创建测试内存文件
3. ✅ 验证 MCP 连接
4. ✅ 评测与现有记忆系统的差异

### 下周 (8/2 - 8/8)

1. 🔲 Docker 部署 n8n (如果资源允许)
2. 🔲 配置 n8n MCP Server
3. 🔲 测试 "博客自动发布" 工作流
4. 🔲 评估 kaeru 的新版本

---

## 🏆 决策总结

| 项目 | 决策 | 理由 |
|------|------|------|
| **Memvid** | 🔴 立即集成 | 零成本、高回报、完美契合 |
| **n8n MCP** | 🟡 下周启动 | 需要基础设施，但价值巨大 |
| **kaeru** | 🟡 持续跟踪 | 潜力巨大但尚未成熟 |

---

*研究日期: 2026-07-28*
*来源: 30+ 网页、GitHub 官方文档、社区讨论、基准测试报告*

---
> 🗺️ 属于 [[MOC-Research|🔬 研究笔记]] · [[knowledge-map|🗺️ 知识地图]]
